package com.ticket.management.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

import com.ticket.management.model.Ticket;

public class TicketingManager {

	public static void main(String[] args) {
		HashMap<Integer,Ticket> TicketLog =new HashMap<Integer,Ticket>();
		HashMap<Integer,String> TicketCategory =new HashMap<Integer,String>();
//		TicketCategory.put(1, "Software Installation");
//		TicketCategory.put(2, "MailBox Creation");
//		TicketCategory.put(3, "network issues");

    	Ticket ticket =new Ticket();
	char choice;
	
	while(true)
	{
		int ch;
		String productCategory;
		int hikeRate;
		System.out.println(" 1-Raise a Ticket \n 2-Exit From the System\n");
		Scanner sc = new Scanner(System.in);
		ch = sc.nextInt();
		
		if(ch == 1 || ch == 2)
		{
			if(ch == 1)
			{
				
				System.out.println("Select Ticketing Category From Below List\n");
				System.out.println("1.Software Installation\n");
				System.out.println("2.MailBox Creation\n");
				System.out.println("3.network issues\n");
				System.out.println("Enter Option:");
				Scanner scCate = new Scanner(System.in);
				int categoryId = scCate.nextInt();
				if(categoryId == 1)
				{
					TicketCategory.put(1, "Software Installation");
					ticket.setTicketCategory("Software Installation");
				}
				else if(categoryId == 2)
				{

					TicketCategory.put(2, "MailBox Creation");
					ticket.setTicketCategory("MailBox Creation");

				}
				else if(categoryId == 3)
				{

					TicketCategory.put(3, "network issues");
					ticket.setTicketCategory("network issues");

				}
				System.out.println("Enter Description related to issue:");
				Scanner scDesc = new Scanner(System.in);
				String ticketDesc = scDesc.next();
				ticket.setTicketDescription(ticketDesc);
				System.out.println("Enter Priority(1.low 2.medium 3.high):");
				Scanner sc2 = new Scanner(System.in);
				int ticketProprity = sc2.nextInt();
				if(ticketProprity == 1)
				{
					ticket.setTicketPriority("low");
				}
				else if(ticketProprity == 2)
				{
					ticket.setTicketPriority("medium");
				}
				else if(ticketProprity == 1)
				{
					ticket.setTicketPriority("high");
				}
				Random rand = new Random();
				int ticketNumber = rand.nextInt();
				  
				 Date date = new Date();
				 ticket.setTicketNumber(ticketNumber);
				 ticket.setLogDate(date);
				 TicketLog.put(ticketNumber, ticket);
				 System.out.println("Ticket Number "+ticketNumber+" logged Successfully at "+date);
					
			}
			else if(ch == 2)
			{
				System.out.println("END");
				break;
			}
			
		}
		else
		{
			System.out.println("Enter Correct Choice");
			continue;
		}
	}
	




	}

}
